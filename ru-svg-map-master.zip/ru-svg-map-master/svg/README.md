### Карта мира ###

![World](https://cdn.rawgit.com/SmartTeleMax/ru-svg-map/e97e11e864490a4e4120a9d4fd9ac80e84d4b0cf/svg/world.svg)


### Карта Российской Федерации  ###

![Russia](https://cdn.rawgit.com/SmartTeleMax/ru-svg-map/e97e11e864490a4e4120a9d4fd9ac80e84d4b0cf/svg/russia.svg)
